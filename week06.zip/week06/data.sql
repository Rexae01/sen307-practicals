USE `sen307_VUGSEN2411780`;
SHOW TABLES;
SELECT COUNT(*) FROM Department;
SELECT COUNT(*) FROM Student;
SELECT COUNT(*) FROM Course;

USE `sen307_VUGSEN2411780`;

INSERT INTO Department (dept_name) VALUES
('Software Engineering'),
('Computer Science'),
('Artificial Intelligence'),
('Data Science'),
('Cybersecurity');

INSERT INTO Course (course_code, course_title, credit_units, description, dept_id) VALUES
('SEN307', 'Database Systems', 3,
 'Relational database design, SQL queries, normalization, transactions and indexing using MySQL.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),
('SEN301', 'Software Architecture', 3,
 'Architectural styles, design patterns, microservices and how to structure large software systems.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),
('COS301', 'Operating Systems', 3,
 'Processes, threads, CPU scheduling, memory management and file systems.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),
('COS305', 'Computer Networks', 3,
 'TCP/IP, routing, switching, LAN and WAN design and network protocols.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),
('AIN301', 'Introduction to Artificial Intelligence', 3,
 'Intelligent agents, search algorithms, knowledge representation and reasoning.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),
('AIN305', 'Machine Learning', 3,
 'Supervised and unsupervised learning, neural networks, deep learning and model evaluation.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),
('AIN307', 'Natural Language Processing', 3,
 'Text processing, word embeddings, language models, sentiment analysis and chatbots.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),
('DTS301', 'Data Visualization and Analytics', 2,
 'Exploratory data analysis, charts, dashboards and telling stories with data.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),
('DTS305', 'Big Data Technologies', 3,
 'Distributed storage and processing of very large datasets with Hadoop and Spark.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),
('CYB301', 'Network Security', 3,
 'Firewalls, cryptography, intrusion detection and protecting networks from attacks.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity'));
 
 SELECT d.dept_name, COUNT(c.course_id) AS courses
FROM Department d LEFT JOIN Course c ON d.dept_id = c.dept_id
GROUP BY d.dept_name;

SELECT dept_id, dept_name FROM Department;
SELECT course_id, course_code FROM Course;

SET @se = (SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering');
SET @cs = (SELECT dept_id FROM Department WHERE dept_name = 'Computer Science');
SET @ai = (SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence');
SET @ds = (SELECT dept_id FROM Department WHERE dept_name = 'Data Science');
SET @cy = (SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity');

INSERT INTO Lecturer (staff_no, full_name, email, dept_id) VALUES
('VUA/ST/101', 'Dr Amaka Okafor',      'a.okafor@vua.edu.ng',   @se),
('VUA/ST/102', 'Dr Musa Bello',        'm.bello@vua.edu.ng',    @se),
('VUA/ST/103', 'Prof Ibrahim Sule',    'i.sule@vua.edu.ng',     @cs),
('VUA/ST/104', 'Dr Ngozi Eze',         'n.eze@vua.edu.ng',      @cs),
('VUA/ST/105', 'Dr Chukwudi Obi',      'c.obi@vua.edu.ng',      @ai),
('VUA/ST/106', 'Dr Fatima Yusuf',      'f.yusuf@vua.edu.ng',    @ai),
('VUA/ST/107', 'Dr Emmanuel Adeleke',  'e.adeleke@vua.edu.ng',  @ds),
('VUA/ST/108', 'Mrs Funke Adebayo',    'f.adebayo@vua.edu.ng',  @ds),
('VUA/ST/109', 'Dr Hassan Abubakar',   'h.abubakar@vua.edu.ng', @cy),
('VUA/ST/110', 'Dr Grace Ekong',       'g.ekong@vua.edu.ng',    @cy);

SELECT lecturer_id, staff_no, full_name FROM Lecturer;

SET @se = (SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering');
SET @cs = (SELECT dept_id FROM Department WHERE dept_name = 'Computer Science');
SET @ai = (SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence');
SET @ds = (SELECT dept_id FROM Department WHERE dept_name = 'Data Science');
SET @cy = (SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity');

INSERT INTO Student (matric_no, full_name, gender, date_of_birth, dept_id) VALUES
('VUG-SEN-24-11780', 'Rebecca Dzarma',       'F', '2007-11-28', @se),
('20231234', 'Ada Obi',            'F', '2005-03-14', @se),
('20231235', 'John Musa',          'M', '2004-11-02', @cs),
('20231236', 'Grace Okon',         'F', '2005-07-21', @se),
('20231237', 'Emeka Nwosu',        'M', '2004-02-09', @cs),
('20231238', 'Fatima Abdullahi',   'F', '2003-12-30', @ai),
('20231239', 'Chinedu Eze',        'M', '2005-05-18', @ai),
('20231240', 'Aisha Bello',        'F', '2006-01-25', @ds),
('20231241', 'Tunde Adeyemi',      'M', '2004-08-12', @cy),
('20231242', 'Ngozi Okeke',        'F', '2005-09-03', @se),
('20231243', 'Ibrahim Sani',       'M', '2003-06-17', @cs),
('20231244', 'Blessing Udoh',      'F', '2006-04-08', @ai),
('20231245', 'Yusuf Danjuma',      'M', '2004-10-29', @ds),
('20231246', 'Zainab Garba',       'F', '2005-02-14', @cy),
('20231247', 'Oluwaseun Balogun',  'M', '2006-11-05', @se),
('20231248', 'Hauwa Yakubu',       'F', '2007-01-19', @cs),
('20231249', 'Chiamaka Obi',       'F', '2004-03-27', @ai),
('20231250', 'Samuel Ojo',         'M', '2005-12-11', @ds),
('20231251', 'Amina Lawal',        'F', '2003-09-22', @cy),
('20231252', 'Peter Akpan',        'M', '2006-08-16', @se);

SELECT COUNT(*) AS students, SUM(dept_id IS NULL) AS missing_dept FROM Student;

INSERT INTO Enrolment (student_id, course_id)
SELECT s.student_id, c.course_id
FROM Student s
JOIN Course c
  ON (s.matric_no, c.course_code) IN (
    ('VUG-SEN-24-11780','SEN307'), ('VUG-SEN-24-11780','SEN301'),
    ('20231234','SEN307'), ('20231234','SEN301'), ('20231234','AIN301'),
    ('20231235','SEN307'), ('20231235','COS301'), ('20231235','COS305'),
    ('20231236','SEN307'), ('20231236','SEN301'),
    ('20231237','COS301'), ('20231237','COS305'), ('20231237','CYB301'),
    ('20231238','AIN301'), ('20231238','AIN305'), ('20231238','AIN307'),
    ('20231239','AIN301'), ('20231239','AIN305'),
    ('20231240','DTS301'), ('20231240','DTS305'),
    ('20231241','CYB301'), ('20231241','COS305'),
    ('20231242','SEN307'), ('20231242','SEN301'),
    ('20231243','COS301'), ('20231243','COS305'),
    ('20231244','AIN305'), ('20231244','AIN307'),
    ('20231245','DTS301'), ('20231245','DTS305'),
    ('20231246','CYB301'), ('20231246','COS305'),
    ('20231247','SEN307'), ('20231247','SEN301'),
    ('20231248','COS301'), ('20231248','AIN301'),
    ('20231249','AIN307'), ('20231249','AIN301'),
    ('20231250','DTS301'), ('20231250','DTS305')
  );

SELECT COUNT(*) AS enrolments FROM Enrolment;

INSERT INTO CourseAllocation (course_id, lecturer_id)
SELECT c.course_id, l.lecturer_id
FROM Course c
JOIN Lecturer l
  ON (c.course_code, l.staff_no) IN (
    ('SEN307','VUA/ST/101'), ('SEN307','VUA/ST/102'),
    ('SEN301','VUA/ST/102'),
    ('COS301','VUA/ST/103'),
    ('COS305','VUA/ST/104'),
    ('AIN301','VUA/ST/105'),
    ('AIN305','VUA/ST/106'),
    ('AIN307','VUA/ST/105'),
    ('DTS301','VUA/ST/107'),
    ('DTS305','VUA/ST/108'),
    ('CYB301','VUA/ST/109')
  );

SELECT COUNT(*) AS allocations FROM CourseAllocation;

SELECT matric_no, full_name, dept_id FROM Student WHERE matric_no = 'VUG-SEN-24-11780';
UPDATE Student
SET dept_id = (SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')
WHERE matric_no = 'VUG-SEN-24-11780';

SELECT matric_no, full_name, dept_id FROM Student WHERE matric_no = 'VUG-SEN-24-11780';

INSERT INTO Department (dept_name) VALUES ('Library and Information Science');

INSERT INTO Student (matric_no, full_name, dept_id)
VALUES ('20239999', 'Transfer Student',
  (SELECT dept_id FROM Department WHERE dept_name = 'Library and Information Science'));

DELETE FROM Department WHERE dept_name = 'Library and Information Science';
INSERT INTO Department (dept_name) VALUES ('Library and Information Science');
UPDATE Student
SET dept_id = (SELECT dept_id FROM Department WHERE dept_name = 'Library and Information Science')
WHERE matric_no = '20239999';
DELETE FROM Department WHERE dept_name = 'Library and Information Science';

UPDATE Student
SET dept_id = (SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')
WHERE matric_no = '20239999';

DELETE FROM Department WHERE dept_name = 'Library and Information Science';

SELECT * FROM Department;

SELECT 'Departments' AS tbl, COUNT(*) AS total FROM Department
UNION ALL SELECT 'Lecturers', COUNT(*) FROM Lecturer
UNION ALL SELECT 'Students', COUNT(*) FROM Student
UNION ALL SELECT 'Courses', COUNT(*) FROM Course
UNION ALL SELECT 'Enrolments', COUNT(*) FROM Enrolment
UNION ALL SELECT 'Allocations', COUNT(*) FROM CourseAllocation;