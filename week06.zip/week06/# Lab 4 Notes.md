# Lab 4 Notes

In Part 4 I got Error 1451: "Cannot delete or update a parent row: a foreign
key constraint fails" when I tried to delete the department "Library and
Information Science". MySQL refuses because the Student table still had a
row (Transfer Student) whose dept_id pointed to that department, so deleting
it would have left a student referring to a department that no longer
exists. This is referential integrity. I fixed it by first updating the
student's dept_id to point to Software Engineering and then deleting the
department, which succeeded. Another fix would have been to define the
foreign key with ON DELETE SET NULL (since Student.dept_id allows NULL) or
ON DELETE CASCADE, so MySQL handles the dependent rows automatically, or to
delete the dependent student first.